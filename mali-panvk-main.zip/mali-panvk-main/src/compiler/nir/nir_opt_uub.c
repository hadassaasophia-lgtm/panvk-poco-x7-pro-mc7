/*
 * Copyright © 2025 Igalia S.L.
 * SPDX-License-Identifier: MIT
 */

#include "util/u_qsort.h"
#include "nir.h"
#include "nir_builder.h"
#include "nir_range_analysis.h"

typedef struct {
   const nir_opt_uub_options *options;
   nir_shader *shader;
   struct hash_table *range_ht;
   struct hash_table *num_lsb_zero_ht;
} opt_uub_state;

static uint32_t
uub(opt_uub_state *state, nir_scalar s)
{
   return nir_unsigned_upper_bound(state->shader, state->range_ht, s);
}

static uint32_t
num_lsb_zero(opt_uub_state *state, nir_scalar s)
{
   return nir_def_num_lsb_zero(state->num_lsb_zero_ht, s);
}

static void
get_srcs(nir_alu_instr *alu, nir_scalar *srcs)
{
   assert(alu->def.num_components == 1);
   nir_scalar def = nir_get_scalar(&alu->def, 0);

   for (unsigned i = 0; i < nir_op_infos[alu->op].num_inputs; i++)
      srcs[i] = nir_scalar_chase_alu_src(def, i);
}

static bool
get_src_and_const(nir_alu_instr *alu, nir_scalar *src, nir_scalar *const_src,
                  unsigned *const_src_idx)
{
   assert(nir_op_infos[alu->op].num_inputs == 2);

   nir_scalar srcs[2];
   get_srcs(alu, srcs);

   for (unsigned i = 0; i < 2; i++) {
      if (nir_scalar_is_const(srcs[i])) {
         *const_src = srcs[i];
         *src = srcs[1 - i];

         if (const_src_idx)
            *const_src_idx = i;

         return true;
      }
   }

   return false;
}

static bool
op_is_add_or(nir_op op)
{
   return op == nir_op_iadd || op == nir_op_ior || op == nir_op_ixor;
}

static bool
get_disjoint_add_src(opt_uub_state *state, nir_scalar *src, unsigned constant)
{
   if (!nir_scalar_is_alu(*src))
      return false;

   if (!op_is_add_or(nir_scalar_alu_op(*src)))
      return false;

   unsigned required_num_lsb = util_last_bit(constant);

   nir_scalar iadd_src[2] = {
      nir_scalar_chase_alu_src(*src, 0),
      nir_scalar_chase_alu_src(*src, 1),
   };

   for (unsigned i = 0; i < 2; i++) {
      if (num_lsb_zero(state, iadd_src[i]) >= required_num_lsb) {
         *src = iadd_src[!i];
         return true;
      }
   }

   return false;
}

static bool
only_used_by_iand_const(nir_def *def, unsigned depth)
{
   if (depth++ >= 2)
      return false;

   nir_foreach_use_including_if(use, def) {
      if (nir_src_is_if(use))
         return false;

      nir_instr *use_instr = nir_src_use_instr(use);
      if (use_instr->type != nir_instr_type_alu)
         return false;

      nir_alu_instr *use_alu = nir_instr_as_alu(use_instr);

      if (op_is_add_or(use_alu->op))
         return only_used_by_iand_const(&use_alu->def, depth);

      if (use_alu->op != nir_op_iand)
         return false;

      if (!nir_src_is_const(use_alu->src[0].src) && !nir_src_is_const(use_alu->src[1].src))
         return false;
   }

   return true;
}

/* iand(src, mask): if mask is constant with N least significant bits set and
 * uub(src) < 2^N, the iand does nothing and can be removed.
 *
 * iand(iadd(src0, src1), mask) -> iand(src1, mask) if src0 won't matter
 * because of its num_lsb_zero
 */
static bool
opt_uub_iand(nir_builder *b, nir_alu_instr *alu, opt_uub_state *state)
{
   assert(alu->op == nir_op_iand);

   nir_scalar src, mask;
   unsigned const_src_idx;

   if (!get_src_and_const(alu, &src, &mask, &const_src_idx))
      return false;

   unsigned first_0 = ffsll(~nir_scalar_as_uint(mask));
   uint32_t low_mask = (1ull << (first_0 - 1)) - 1;

   if (low_mask != 0 && uub(state, src) <= low_mask) {
      b->cursor = nir_after_def(src.def);
      nir_def_replace(&alu->def, nir_mov_scalar(b, src));
      return true;
   } else if (get_disjoint_add_src(state, &src, nir_scalar_as_uint(mask))) {
      nir_src_rewrite(&alu->src[!const_src_idx].src, src.def);
      alu->src[!const_src_idx].swizzle[0] = src.comp;
      return true;
   } else if (nir_scalar_is_alu(src) && op_is_add_or(nir_scalar_alu_op(src))) {
      /* Look through some level of add/or, but only if it's only used by iand with
       * constants. This is slightly better than used_once.
       */
      if (!only_used_by_iand_const(src.def, 0))
         return false;

      nir_scalar iadd_src[2];
      bool progress = false;
      for (unsigned i = 0; i < 2; i++) {
         iadd_src[i] = nir_scalar_chase_alu_src(src, i);
         progress |= get_disjoint_add_src(state, &iadd_src[i], nir_scalar_as_uint(mask));
      }

      if (!progress)
         return false;

      b->cursor = nir_before_instr(&alu->instr);
      nir_def *src0 = nir_mov_scalar(b, iadd_src[0]);
      nir_def *src1 = nir_mov_scalar(b, iadd_src[1]);
      nir_def *ior = nir_build_alu2(b, nir_scalar_alu_op(src), src0, src1);
      nir_src_rewrite(&alu->src[!const_src_idx].src, ior);
      alu->src[!const_src_idx].swizzle[0] = 0;
      return true;
   }

   return false;
}

static nir_op
invert_cmp(nir_op op)
{
   switch (op) {
   case nir_op_ult:
      return nir_op_uge;
   case nir_op_uge:
      return nir_op_ult;
   case nir_op_ilt:
      return nir_op_ige;
   case nir_op_ige:
      return nir_op_ilt;
   default:
      UNREACHABLE("unexpected cmp op");
   }
}

/* ult src, const: if uub(src) < cmp -> true
 * uge src, const: if uub(src) < cmp -> false
 * ilt src, const: if uub(src) >= 0 && cmp <  0 -> false
 *                 if uub(src) >= 0 && cmp >= 0 -> ult src, const
 * ige src, const: if uub(src) >= 0 && cmp <  0 -> true
 *                 if uub(src) >= 0 && cmp >= 0 -> uge src, const
 */
static bool
opt_uub_cmp(nir_builder *b, nir_alu_instr *alu, opt_uub_state *state)
{
   assert(alu->op == nir_op_ult || alu->op == nir_op_uge ||
          alu->op == nir_op_ilt || alu->op == nir_op_ige);

   if (nir_src_bit_size(alu->src[0].src) > 32)
      return false;

   nir_scalar src, cmp;
   unsigned const_src_idx;

   if (!get_src_and_const(alu, &src, &cmp, &const_src_idx))
      return false;

   uint32_t src_uub = uub(state, src);

   /* To make the code below more uniform, make sure the constant is always
    * the RHS operand by inverting the opcode when it isn't.
    */
   nir_op op = const_src_idx == 0 ? invert_cmp(alu->op) : alu->op;

   if (op == nir_op_ilt || op == nir_op_ige) {
      /* If src could be negative, there's nothing we can prove. */
      if (util_sign_extend(src_uub, src.def->bit_size) < 0)
         return false;

      if (nir_scalar_as_int(cmp) < 0) {
         /* src >= 0 && cmp < 0: ige -> true, ilt -> false  */
         bool replacement = op == nir_op_ige;
         b->cursor = nir_after_instr(&alu->instr);
         nir_def_replace(&alu->def, nir_imm_bool(b, replacement));
         return true;
      }

      /* src >= 0 && cmp >= 0: same as unsigned cmp. */
      op = op == nir_op_ilt ? nir_op_ult : nir_op_uge;
   }

   if (src_uub >= nir_scalar_as_uint(cmp))
      return false;

   /* Replace ult with true, uge with false. */
   bool replacement = op == nir_op_ult;
   b->cursor = nir_after_instr(&alu->instr);
   nir_def_replace(&alu->def, nir_imm_bool(b, replacement));
   return true;
}

/* umin src, const: if uub(src) <= const -> src
 * umax src, const: if uub(src) <= const -> const
 * imin src, const: if uub(src) >= 0 && const <  0 -> const
 *                  if uub(src) >= 0 && const >= 0 -> umin src, const
 * imax src, const: if uub(src) >= 0 && const <  0 -> src
 *                  if uub(src) >= 0 && const >= 0 -> umax src, const
 */
static bool
opt_uub_minmax(nir_builder *b, nir_alu_instr *alu, opt_uub_state *state)
{
   assert(alu->op == nir_op_umin || alu->op == nir_op_umax ||
          alu->op == nir_op_imin || alu->op == nir_op_imax);

   nir_scalar src, const_src;

   if (!get_src_and_const(alu, &src, &const_src, NULL))
      return false;

   uint32_t src_uub = uub(state, src);
   nir_op op = alu->op;

   if (op == nir_op_imin || op == nir_op_imax) {
      /* If src could be negative, there's nothing we can prove. */
      if (util_sign_extend(src_uub, src.def->bit_size) < 0)
         return false;

      if (nir_scalar_as_int(const_src) < 0) {
         /* src >= 0 && const < 0: imin -> const, imax -> src  */
         nir_scalar replacement = alu->op == nir_op_imin ? const_src : src;
         b->cursor = nir_after_instr(&alu->instr);
         nir_def_replace(&alu->def, nir_mov_scalar(b, replacement));
         return true;
      }

      /* src >= 0 && cmp >= 0: same as umin/umax. */
      op = op == nir_op_imin ? nir_op_umin : nir_op_umax;
   }

   if (src_uub > nir_scalar_as_uint(const_src))
      return false;

   nir_scalar replacement = op == nir_op_umax ? const_src : src;
   b->cursor = nir_after_instr(&alu->instr);
   nir_def_replace(&alu->def, nir_mov_scalar(b, replacement));
   return true;
}

static bool
try_replace_imul(nir_builder *b, nir_alu_instr *alu, nir_scalar *srcs,
                 uint32_t *src_uubs, unsigned bits_used, nir_op op)
{
   uint32_t max = (1 << bits_used) - 1;

   if (src_uubs[0] > max || src_uubs[1] > max)
      return false;

   b->cursor = nir_after_instr(&alu->instr);
   nir_def_replace(&alu->def, nir_build_alu2(b, op, nir_mov_scalar(b, srcs[0]),
                                             nir_mov_scalar(b, srcs[1])));
   return true;
}

/* imul src0, src1: if uub(srci) < UINT16_MAX -> umul_16x16 src0, src1
 * imul src0, src1: if uub(srci) < UINT24_MAX -> umul24 src0, src1
 * imul src0, src1: if uub(srci) < UINT23_MAX -> imul24 src0, src1
 */
static bool
opt_uub_imul(nir_builder *b, nir_alu_instr *alu, opt_uub_state *state)
{
   assert(alu->op == nir_op_imul);

   if (!state->options->opt_imul || alu->def.bit_size != 32)
      return false;

   const nir_shader_compiler_options *shader_options = b->shader->options;

   nir_scalar srcs[2];
   get_srcs(alu, srcs);
   uint32_t src_uubs[] = {uub(state, srcs[0]), uub(state, srcs[1])};

   if (shader_options->has_umul_16x16 &&
       try_replace_imul(b, alu, srcs, src_uubs, 16, nir_op_umul_16x16)) {
      return true;
   }

   if ((shader_options->has_umul24 || shader_options->has_mul24_relaxed) &&
       try_replace_imul(b, alu, srcs, src_uubs, 24,
                        b->shader->options->has_mul24_relaxed
                           ? nir_op_umul24_relaxed
                           : nir_op_umul24)) {
      return true;
   }

   /* imul24 sign-extends its 24-bit sources which may give the wrong result
    * if the unsigned upper bound fits in 24-bits. Check if it fits is 23-bits
    * to avoid sign-extension.
    */
   if ((shader_options->has_imul24 || shader_options->has_mul24_relaxed) &&
       try_replace_imul(b, alu, srcs, src_uubs, 23,
                        b->shader->options->has_mul24_relaxed
                           ? nir_op_imul24_relaxed
                           : nir_op_imul24)) {
      return true;
   }

   return false;
}

/* shr(iadd(src0, src1), #c) -> shr(src0, #c) if src1 is fully shifted away. */
static bool
opt_uub_shr(nir_builder *b, nir_alu_instr *alu, opt_uub_state *state)
{
   assert(alu->op == nir_op_ishr || alu->op == nir_op_ushr);

   nir_scalar src, shift;
   unsigned const_src_idx;

   if (!get_src_and_const(alu, &src, &shift, &const_src_idx) || const_src_idx != 1)
      return false;

   if (!nir_scalar_is_alu(src))
      return false;

   unsigned cshift = nir_scalar_as_uint(shift) & (alu->def.bit_size - 1);

   nir_op op = nir_scalar_alu_op(src);

   if (!op_is_add_or(op))
      return false;

   nir_scalar iadd_src[2] = {
      nir_scalar_chase_alu_src(src, 0),
      nir_scalar_chase_alu_src(src, 1),
   };

   for (unsigned i = 0; i < 2; i++) {
      if (uub(state, iadd_src[i]) > BITFIELD64_MASK(cshift))
         continue;

      if (op == nir_op_iadd && num_lsb_zero(state, iadd_src[!i]) < cshift)
         continue;

      nir_src_rewrite(&alu->src[0].src, iadd_src[!i].def);
      alu->src[0].swizzle[0] = iadd_src[!i].comp;
      return true;
   }

   return false;
}

static bool
alu_op_nuw(nir_op op, unsigned bit_size, uint32_t src0, uint32_t src1)
{
   uint32_t max = u_uintN_max(bit_size);
   switch (op) {
   case nir_op_iadd:
      return max - src0 >= src1;
   case nir_op_ishl:
      return src1 <= bit_size - util_last_bit(src0);
   case nir_op_imul:
      return src0 == 0 || src1 <= (max / src0);
   case nir_op_iand:
   case nir_op_ior:
   case nir_op_ixor:
      return true;
   default:
      UNREACHABLE("unexpected op");
   }
}

struct u2u64_src {
   nir_scalar scalar;
   uint32_t uub;
};

struct reduce_bit_size_state {
   opt_uub_state *state;
   nir_builder *b;
   struct util_dynarray u2u64_srcs;
   unsigned rewritten_u2u64;
};

static bool
is_u2u64(nir_scalar scalar, nir_scalar *src)
{
   /* We generally don't want to move constants into the 32-bit additions
    * because it can currently make load/store vectorization less effective.
    */
   if (nir_scalar_is_alu(scalar) && nir_scalar_alu_op(scalar) == nir_op_u2u64) {
      *src = nir_scalar_chase_alu_src(scalar, 0);
      return src->def->bit_size == 32;
   }
   return false;
}

/* We both gather and rewrite with the same function so that we're certain that
 * we visit the same sources in the same order.
 */
static nir_scalar
alu_u2u64_visit(nir_alu_instr *alu, unsigned depth, bool rewrite, struct reduce_bit_size_state *state)
{
   struct util_dynarray *u2u64_srcs = &state->u2u64_srcs;

   if (depth >= 16)
      return nir_get_scalar(&alu->def, 0);

   nir_scalar srcs[2];
   get_srcs(alu, srcs);
   nir_scalar new_srcs[2] = { srcs[0], srcs[1] };
   for (unsigned i = 0; i < 2; i++) {
      nir_scalar scalar;
      if (is_u2u64(srcs[i], &scalar)) {
         if (rewrite) {
            struct u2u64_src *src = util_dynarray_element(
               &state->u2u64_srcs, struct u2u64_src, state->rewritten_u2u64++);
            if (!src->scalar.def)
               new_srcs[i].def = NULL;
         } else {
            struct u2u64_src src;
            src.scalar = nir_scalar_chase_movs(scalar);
            src.uub = uub(state->state, scalar);
            util_dynarray_append(u2u64_srcs, src);
         }
      } else if (nir_scalar_is_alu(srcs[i]) && srcs[i].def->num_components == 1 &&
                 nir_scalar_alu_op(srcs[i]) == alu->op) {
         /* Checking if this instruction is only used once might avoid doing this optimization in
          * cases where it's harmful, but in practice, it seems to work out better without the check. */
         new_srcs[i] = alu_u2u64_visit(nir_scalar_as_alu(srcs[i]), depth + 1, rewrite, state);
      }
   }

   if (!rewrite || (!new_srcs[0].def && !new_srcs[1].def)) {
      return nir_get_scalar(NULL, 0);
   } else if (!new_srcs[0].def) {
      return new_srcs[1];
   } else if (!new_srcs[1].def) {
      return new_srcs[0];
   } else if (!nir_scalar_equal(srcs[0], new_srcs[0]) ||
              !nir_scalar_equal(srcs[1], new_srcs[1])) {
      nir_builder *b = state->b;
      nir_def *def = nir_build_alu2(b, alu->op, nir_mov_scalar(b, new_srcs[0]),
                                    nir_mov_scalar(b, new_srcs[1]));
      return nir_get_scalar(def, 0);
   } else {
      return nir_get_scalar(&alu->def, 0);
   }
}

static int
sort_u2u64(const void *a_, const void *b_, void *state_)
{
   const size_t *a = a_;
   const size_t *b = b_;
   struct reduce_bit_size_state *state = state_;
   struct u2u64_src *srcs = util_dynarray_begin(&state->u2u64_srcs);
   if (srcs[*a].uub < srcs[*b].uub)
      return 1;
   if (srcs[*a].uub > srcs[*b].uub)
      return -1;
   return *a > *b ? 1 : -1;
}

/* op(u2u64(src0@32), u2u64(src1@32)): if nuw(src0 op src1) -> u2u64(op(src0, src1)) */
static bool
opt_uub_alu_u2u64_recursive(nir_builder *b, nir_alu_instr *alu, opt_uub_state *state)
{
   /* Skip if we will process this instruction later. */
   if (list_is_singular(&alu->def.uses)) {
      nir_src *use = list_first_entry(&alu->def.uses, nir_src, use_link);
      assert(!nir_src_is_if(use));
      nir_instr *use_instr = nir_src_use_instr(use);
      if (use_instr->type == nir_instr_type_alu && nir_instr_as_alu(use_instr)->op == alu->op)
         return false;
   }

   struct reduce_bit_size_state reduce_state;
   reduce_state.state = state;
   reduce_state.b = b;
   reduce_state.rewritten_u2u64 = 0;
   b->cursor = nir_after_instr(&alu->instr);
   struct u2u64_src u2u64_srcs_stack[64];
   util_dynarray_init_from_stack(&reduce_state.u2u64_srcs, u2u64_srcs_stack,
                                 sizeof(u2u64_srcs_stack));

   /* Gather list of u2u64 sources. */
   alu_u2u64_visit(alu, 0, false, &reduce_state);

   struct u2u64_src *u2u64_srcs = util_dynarray_begin(&reduce_state.u2u64_srcs);
   unsigned num_u2u64_srcs = util_dynarray_num_elements(&reduce_state.u2u64_srcs, struct u2u64_src);
   if (num_u2u64_srcs <= 1) {
      util_dynarray_fini(&reduce_state.u2u64_srcs);
      return false;
   }

   /* Sort u2u64 sources from largest uub to smallest, since that probably improves
    * chances of avoiding overflow in the combine loop. Keep the order of the array,
    * because we depend on that for rewriting the expression. */
   size_t *order = malloc(sizeof(size_t) * num_u2u64_srcs);
   for (unsigned i = 0; i < num_u2u64_srcs; i++)
      order[i] = i;
   util_qsort_r(order, num_u2u64_srcs, sizeof(size_t), &sort_u2u64, &reduce_state);

   /* Separate and combine 32-bit values, in 32-bit when possible. */
   nir_def *val32 = NULL;
   for (unsigned i = 0; i < num_u2u64_srcs; i++) {
      struct u2u64_src *src_i = &u2u64_srcs[order[i]];
      if (!src_i->scalar.def)
         continue;
      struct u2u64_src res = *src_i;

      for (unsigned j = i + 1; j < num_u2u64_srcs; j++) {
         struct u2u64_src *src_j = &u2u64_srcs[order[j]];
         if (!src_j->scalar.def || !alu_op_nuw(alu->op, 32, res.uub, src_j->uub))
            continue;

         nir_def *def = nir_build_alu2(b, alu->op, nir_mov_scalar(b, res.scalar),
                                       nir_mov_scalar(b, src_j->scalar));
         if (nir_def_is_alu(def) && (alu->op == nir_op_iadd || alu->op == nir_op_imul))
            nir_def_as_alu(def)->no_unsigned_wrap = true;
         res.scalar = nir_get_scalar(def, 0);
         res.uub = uub(state, res.scalar);

         src_j->scalar.def = NULL;
      }

      if (res.scalar.def != src_i->scalar.def) {
         nir_def *val32_2 = nir_u2u64(b, nir_mov_scalar(b, res.scalar));
         if (val32)
            val32 = nir_build_alu2(b, alu->op, val32, val32_2);
         else
            val32 = val32_2;

         src_i->scalar.def = NULL;
      }
   }
   free(order);

   /* Rewrite expression. */
   nir_scalar res = alu_u2u64_visit(alu, 0, true, &reduce_state);
   util_dynarray_fini(&reduce_state.u2u64_srcs);

   assert(res.def == &alu->def || val32);
   if (val32 && res.def)
      nir_def_replace(&alu->def, nir_build_alu2(b, alu->op, nir_mov_scalar(b, res), val32));
   else if (!res.def)
      nir_def_replace(&alu->def, val32);
   else
      return false;
   return true;
}

/* ishl(u2u64(src0@32), u2u64(src1@32)): if nuw(src0 << src1) -> u2u64(ishl(src0, src1)) */
static bool
opt_uub_alu_u2u64_ishl(nir_builder *b, nir_alu_instr *alu, opt_uub_state *state)
{
   nir_scalar srcs[2];
   get_srcs(alu, srcs);
   if (!is_u2u64(srcs[0], &srcs[0]))
      return false;

   if (alu_op_nuw(alu->op, 32, uub(state, srcs[0]), uub(state, srcs[1]))) {
      b->cursor = nir_after_instr(&alu->instr);
      nir_def *def = nir_ishl_nuw(b, nir_mov_scalar(b, srcs[0]), nir_mov_scalar(b, srcs[1]));
      nir_def_replace(&alu->def, nir_u2u64(b, def));
      return true;
   }

   return false;
}

/* i2i64 -> u2u64 */
static bool
opt_uub_i2i64(nir_builder *b, nir_alu_instr *alu, opt_uub_state *state)
{
   nir_scalar src;
   get_srcs(alu, &src);
   if (src.def->bit_size != 64 && uub(state, src) <= (uint32_t)u_intN_max(src.def->bit_size)) {
      alu->op = nir_op_u2u64;
      return true;
   }
   return false;
}

static bool
src_is_const(nir_src *src, void *data)
{
   return nir_src_is_const(*src);
}

static bool
opt_uub(nir_builder *b, nir_alu_instr *alu, void *data)
{
   /* Ignore non-scalar instructions to simplify the code. */
   if (alu->def.num_components > 1)
      return false;

   /* If all sources are constant, let constant folding handle this. */
   if (nir_foreach_src(&alu->instr, src_is_const, NULL))
      return false;

   opt_uub_state *state = data;

   /* If the upper bound is zero, zero is the only possible value.
    * nir_unsigned_upper_bound calculates 32-bit upper bounds so ignore 64-bit
    * instructions.
    */
   if (alu->def.bit_size <= 32 && uub(state, nir_get_scalar(&alu->def, 0)) == 0) {
      b->cursor = nir_after_def(&alu->def);
      nir_def_replace(&alu->def, nir_imm_zero(b, 1, alu->def.bit_size));
      return true;
   }

   switch (alu->op) {
   case nir_op_iand:
      if (alu->def.bit_size <= 32)
         return opt_uub_iand(b, alu, state);
      FALLTHROUGH;
   case nir_op_ior:
   case nir_op_ixor:
      return alu->def.bit_size == 64 && opt_uub_alu_u2u64_recursive(b, alu, state);
   case nir_op_ult:
   case nir_op_uge:
   case nir_op_ilt:
   case nir_op_ige:
      return alu->def.bit_size <= 32 && opt_uub_cmp(b, alu, state);
   case nir_op_umin:
   case nir_op_umax:
   case nir_op_imin:
   case nir_op_imax:
      return alu->def.bit_size <= 32 && opt_uub_minmax(b, alu, state);
   case nir_op_ishr:
   case nir_op_ushr:
      return alu->def.bit_size <= 32 && opt_uub_shr(b, alu, state);
   case nir_op_imul:
      if (alu->def.bit_size <= 32)
         return opt_uub_imul(b, alu, state);
      FALLTHROUGH;
   case nir_op_iadd:
      return alu->def.bit_size == 64 && opt_uub_alu_u2u64_recursive(b, alu, state);
   case nir_op_ishl:
      return alu->def.bit_size == 64 && opt_uub_alu_u2u64_ishl(b, alu, state);
   case nir_op_i2i64:
      return opt_uub_i2i64(b, alu, state);
   default:
      return false;
   }
}

/* Performs a number of optimizations that make use of
 * nir_unsigned_upper_bound to simplify/remove instructions.
 */
bool
nir_opt_uub(nir_shader *shader, const nir_opt_uub_options *options)
{
   opt_uub_state state = {
      .options = options,
      .shader = shader,
      .range_ht = _mesa_pointer_hash_table_create(NULL),
      .num_lsb_zero_ht = _mesa_pointer_hash_table_create(NULL),
   };

   bool progress =
      nir_shader_alu_pass(shader, opt_uub, nir_metadata_control_flow, &state);

   _mesa_hash_table_destroy(state.range_ht, NULL);
   _mesa_hash_table_destroy(state.num_lsb_zero_ht, NULL);
   return progress;
}
